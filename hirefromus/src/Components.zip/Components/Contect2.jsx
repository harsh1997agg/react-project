import React from 'react';
import "./Contect2.css";

function Contect2(props) {
    return (
        <div>
            <div className="col-12 row exp"  style={{backgroundColor:"yellow",height:"200px"}}>
    <div className="col-2 oofset-2 text-center ac" style={{backgroundColor:"red",height:"100px",position:"relative",top:"50px"}}>ds</div>
   
    <div className="col-2 oofset-2 text-center bc" style={{backgroundColor:"pink",height:"100px",position:"relative",top:"50px"}}>ds</div>
    <div className="col-4 ">ds</div>
</div>
        </div>
    );
}

export default Contect2;