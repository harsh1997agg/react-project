import React from 'react';
import "./Huddle.css";
function Huddle(props) {
    return (
        <div>
<div class="row  col-12 mt-5" style={{position:"relative", height: "300px"}}>
<div className="huddle row col-12 mt-5" id="huddle"  style={{position:"absolute",zIndex:"1"}}  >
        <div className="col-12 row pl-lg-5 ">
          <div className="col-lg-11 row  offset-lg-1 pl-lg-4" >

          <div className="row offset-1 col-10 pl-0 offset-lg-0 col-lg-11 huddle-content-tm"  ><p class="huddle-content-tm-p">TM</p></div>
         <div className="row offset-1 col-10 pl-0 offset-lg-0 col-lg-11 huddle-content" >

            
            <div className="col-lg-2  text-center hud-sec hud huddle-content-child1"   ><p class="hud-p1">H</p></div>
            <div className="col-lg-2  text-center hud-sec hud huddle-content-child2"  ><p class="hud-p2">U</p></div>
            <div className="col-lg-2  text-center hud-sec hud huddle-content-child3" ><p class="hud-p3">D</p></div>
            
            
            <div className="col-lg-2  text-center dle-sec hud huddle-content-child4" ><p class="hud-p4">D</p></div>
            <div className="col-lg-2  text-center dle-sec hud huddle-content-child5" ><p class="hud-p5">L</p></div>
            <div className="col-lg-2 text-center dle-sec hud huddle-content-child6 pl-0" ><p class="hud-p6">E</p></div>
          
        </div>

       
       



          </div>
        

        
      </div>
     
      </div>


      <div className="huddle1 mt-5"   style={{position:"absolute",zIndex:"-1"}}  >
        <div className="col-12 row pl-lg-5 huddle11">
          <div className="col-lg-11 row  offset-lg-1 pl-lg-4 huddle111" >

        
         <div className="row offset-1 col-10 pl-0 offset-lg-0 col-lg-11 huddle1-content mt-4" >

            <div className="col-7 huddle1-content-p1">
            <p><span class="spanhire">H</span>ire<span class="spanhire">U</span>pskill<span class="spanhire">D</span>evelop</p>
            </div>
            <div className="col-5 huddle1-content-p2 pl-4 mt-3">
            <p style={{opacity:0}} id="huddle1-content-p21" >Futurense onboards and develops candidates with a holistic training approach, all while paying them</p>
            </div>

            <div class="col-12 mt-5"></div>
            <div className="col-5 huddle1-content-p2 pl-4 mt-4">
            <p style={{opacity:0}} id="huddle1-content-p211">We deploy the candidates as contractual<br/> employees with your organization to deliver<br/> impact at scale!</p>
            </div>

            <div className="col-7 huddle1-content-p1 mt-1">
            <p><span class="spanhire">D</span>eploy<span class="spanhire">L</span>earn<span class="spanhire">E</span>ngage</p>
            </div>
            





        </div>

       
       



          </div>
        

        
      </div>
     
      </div>

      </div>


        {/* <div className="col-12 row exp1"  style={{backgroundColor:"yellow",height:"200px"}}>
<div className="col-2 oofset-2 text-center ac1" style={{backgroundColor:"red",height:"100px",position:"relative",top:"50px"}}>ds</div>

<div className="col-2 oofset-2 text-center bc1" style={{height:"100px",position:"relative",top:"50px"}}>ds</div>
<div className="col-4 ">ds</div>
</div> */}
    </div>
    );
}

export default Huddle;